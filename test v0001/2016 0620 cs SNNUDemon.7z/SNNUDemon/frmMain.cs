﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Configuration;


namespace SNNUDemon
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

       
        private string appTitle = null;
        private string appTipContents = null;

        private string alertTitle = "温馨提醒";
        private string alertContent = "您设定的触发时间到了，是否现在开始？";

        private string executeFileName = null;
        private string executeFileArgs = null;

        private int timerInterval = 4200;

        private void frmMain_Load(object sender, EventArgs e)
        {
            
            this.alertTitle =  ConfigurationManager.AppSettings["alertTitle"];
            this.alertContent = ConfigurationManager.AppSettings["alertContent"];

            this.appTitle = ConfigurationManager.AppSettings["appTitle"];
            this.appTipContents = ConfigurationManager.AppSettings["appTipContents"];

            this.executeFileName = ConfigurationManager.AppSettings["executeFileName"];
            this.executeFileArgs = ConfigurationManager.AppSettings["executeFileArgs"];


            this.timerInterval = Convert.ToInt32(ConfigurationManager.AppSettings["timerInterval"]);

            this.tmMain.Enabled = true;
            this.tmMain.Interval = this.timerInterval * 1000;

            this.Text = this.appTitle;
            this.lblAppTipContents.Text = this.appTipContents;
        }


        private void tmMain_Tick(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show(alertContent, alertTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.No)
                return;

            System.Diagnostics.Process process = new System.Diagnostics.Process();
            process.StartInfo.FileName = this.executeFileName;
            process.StartInfo.Arguments = this.executeFileArgs;
            process.Start();
        }
    }
}
