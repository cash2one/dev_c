﻿namespace SNNUDemon
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmMain = new System.Windows.Forms.Timer(this.components);
            this.lblAppTipContents = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tmMain
            // 
            this.tmMain.Enabled = true;
            this.tmMain.Interval = 10000;
            this.tmMain.Tick += new System.EventHandler(this.tmMain_Tick);
            // 
            // lblAppTipContents
            // 
            this.lblAppTipContents.AutoSize = true;
            this.lblAppTipContents.Font = new System.Drawing.Font("Microsoft YaHei", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblAppTipContents.Location = new System.Drawing.Point(12, 32);
            this.lblAppTipContents.Name = "lblAppTipContents";
            this.lblAppTipContents.Size = new System.Drawing.Size(360, 64);
            this.lblAppTipContents.TabIndex = 0;
            this.lblAppTipContents.Text = "正在工作中……";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 128);
            this.Controls.Add(this.lblAppTipContents);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "守护者一号";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer tmMain;
        private System.Windows.Forms.Label lblAppTipContents;
    }
}

